package com.ct.controller;

public interface UrlNames {
	static final String indexPage = "index";
	static final String registerPage = "register";
	static final String addPage = "addpage";
	static final String displayTvPage = "displayTv";
	static final String retrievePage = "retrieve";

}
