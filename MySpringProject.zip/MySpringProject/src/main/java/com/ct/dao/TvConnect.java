package com.ct.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

public class TvConnect implements ITvConnect {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	
	@Override
	public int addTv(Tv t) {
		
		String query = "insert into Tv values(?,?,?,?,?,?)";
		int a = jdbcTemplate.update(query, new Object[] {t.getTvName(), t.getTvBrand(), t.getTvPrice(), t.getTvQuantity(), t.getTvDescription(), t.getTvDiscount()});
		return a;
	}

	@Override
	public void displayTv() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void retriveTv() {
		// TODO Auto-generated method stub
		
	}

	
}
