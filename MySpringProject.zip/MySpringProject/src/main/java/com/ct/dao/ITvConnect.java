package com.ct.dao;

import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

public interface ITvConnect {

	public int addTv(Tv t);
	public void displayTv();
	public void retriveTv();
}
