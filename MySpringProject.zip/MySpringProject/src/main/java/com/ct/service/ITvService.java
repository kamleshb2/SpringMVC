package com.ct.service;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

@Component
public interface ITvService {
	
	public ModelAndView predAdd(); 
	public int addTv(Tv t);
	public void displayTv();
	public void retriveTv();

}
